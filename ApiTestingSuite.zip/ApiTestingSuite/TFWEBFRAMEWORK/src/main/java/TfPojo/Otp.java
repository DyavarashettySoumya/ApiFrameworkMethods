package TfPojo;

public class Otp {
    int otp;
    public int getOtp() {
        return otp;
    }

    public void setOtp(int otp) {
        this.otp = otp;
    }

}
