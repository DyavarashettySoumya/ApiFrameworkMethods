package TfPojo;

public class otpResponse {
    String msg;
    String Id;


    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getId() {
        return Id;
    }

    public void setId(String tenantId) {
        this.Id = tenantId;
    }
}
